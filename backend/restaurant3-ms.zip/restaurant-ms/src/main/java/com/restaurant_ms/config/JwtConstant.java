package com.restaurant_ms.config;

public class JwtConstant {
    public static final String SECRET_KEY="driugfhdrfuighsdofhihfsozgvsfdgmp";
    public static final String JWT_HEADER="Authorization";
}
