package com.restaurant_ms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestaurantMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestaurantMsApplication.class, args);
	}

}
