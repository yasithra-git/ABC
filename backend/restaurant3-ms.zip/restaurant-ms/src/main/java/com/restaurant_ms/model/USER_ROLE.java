package com.restaurant_ms.model;

public enum USER_ROLE {
    ROLE_CUSTOMER,
    ROLE_RESTAURANT_STAFF,
    ROLE_ADMIN
}
