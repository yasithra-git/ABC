package com.restaurant_ms.response;

import lombok.Data;

@Data
public class MessageResponse {
    private String message;
}
