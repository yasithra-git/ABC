package com.restaurant_ms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
